import json
import sqlite3
import datetime
import os
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet
 
# Both publisher and subscriber live in mqtt/ — key file is in the same folder
KEY_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "secret.key")
 
# Path to the shared database one level up, inside /db/
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "db", "Logistic.db")
 
# Load the shared key that the publisher saved to disk.
# Both sides must use the same key — Fernet is symmetric encryption.
try:
    with open(KEY_PATH, "rb") as f:
        key = f.read()
    cipher = Fernet(key)
    print("=" * 55)
    print("[SUB] Secret key loaded from secret.key")
    print(f"[SUB] Key: {key.decode()}")
    print("=" * 55)
except FileNotFoundError:
    print("[SUB] ERROR: secret.key not found!")
    print("      Run encrypted_publisher.py first to generate the key.")
    exit(1)
 
BROKER = "broker.hivemq.com"
PORT   = 1883
 
 
def on_connect(client, userdata, flags, reason_code, properties):
    if reason_code == 0:
        print("[SUB] Connected to MQTT broker")
        client.subscribe("truck/location")
        client.subscribe("parcel/status")
        print("[SUB] Subscribed to truck/location and parcel/status")
        print("[SUB] Waiting for encrypted messages...\n")
    else:
        print(f"[SUB] Connection error, code: {reason_code}")
 
 
def on_message(client, userdata, msg):
    topic = msg.topic
 
    # Step 1: decrypt the raw bytes received from the broker,
    # then parse the JSON back into a Python dict.
    try:
        decrypted_bytes = cipher.decrypt(msg.payload)
        payload = json.loads(decrypted_bytes.decode())
        print(f"[SUB] Topic : {topic}")
        print(f"      Cipher: {msg.payload[:50]}...")
        print(f"      Plain : {payload}")
    except Exception as e:
        # Wrong key or corrupted message — skip safely
        print(f"[SUB] Decryption/parse error on '{topic}': {e}")
        return
 
    # Step 2: write the decrypted data into SQLite.
    # timeout=10 avoids write conflicts if dashboard.py is also accessing the DB.
    now  = datetime.datetime.now().isoformat()
    conn = sqlite3.connect(DB_PATH, timeout=10)  # [CHANGED] MQT.db → ../db/Logistic.db
    cursor = conn.cursor()
 
    try:
        if topic == "truck/location":
            vehicle_id = payload.get("vehicle_id", 1)
            lat        = payload.get("lat")
            lon        = payload.get("lon")
            # [CHANGED] "Traction logs" → traction_logs  (matches actual table name in Logistic.db)
            cursor.execute("""
                INSERT INTO traction_logs (vehicle_id, latitude, longitude, speed, timestamp)
                VALUES (?, ?, ?, 0, ?)
            """, (vehicle_id, lat, lon, now))
            print(f"[LOG] GPS saved for vehicle #{vehicle_id}: {lat:.4f}, {lon:.4f}\n")
 
        elif topic == "parcel/status":
            # [CHANGED] parcel_name → tracking_number  (parcels table uses tracking_number)
            tracking_number = payload.get("parcel_name")
            status          = payload.get("status")
            del_time        = now if status == "delivered" else None  # [FIXED]
 
            # Upsert: update if parcel already exists, otherwise insert a fresh row
            cursor.execute("SELECT parcel_id FROM parcels WHERE tracking_number=?", (tracking_number,))
            if cursor.fetchone():
                cursor.execute(
                    "UPDATE parcels SET status=?, delivered_at=? WHERE tracking_number=?",
                    (status, del_time, tracking_number)
                )
            else:
                # [CHANGED] INSERT now includes sender/receiver/destination (NOT NULL in schema)
                cursor.execute("""
                    INSERT INTO parcels (tracking_number, sender, receiver, vehicle_id, destination, status, created_at)
                    VALUES (?, 'Warehouse', 'Client', 1, 'EXPO', ?, ?)
                """, (tracking_number, status, now))
            print(f"[STAT] Parcel '{tracking_number}' → {status}\n")
 
        conn.commit()
    except sqlite3.Error as e:
        print(f"[SUB] Database error: {e}")
    finally:
        conn.close()
 
 
if __name__ == "__main__":
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    client.on_connect = on_connect
    client.on_message = on_message
 
    client.connect(BROKER, PORT, 60)
    try:
        client.loop_forever()
    except KeyboardInterrupt:
        print("\n[SUB] Disconnecting...")
        client.disconnect()