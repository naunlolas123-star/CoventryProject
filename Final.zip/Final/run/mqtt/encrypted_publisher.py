import json
import time
import random
import datetime
import os
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet
 
# Save secret.key next to this script so the subscriber (same folder) can read it
KEY_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "secret.key")
 
# Generate key once and reuse it forever — subscriber always has the same key
# regardless of start order.
if os.path.exists(KEY_PATH):
    with open(KEY_PATH, "rb") as f:
        key = f.read()
    print("=" * 55)
    print("[PUB] Existing key loaded from secret.key")
else:
    key = Fernet.generate_key()
    with open(KEY_PATH, "wb") as f:
        f.write(key)
    print("=" * 55)
    print("[PUB] New key generated and saved to secret.key")
 
cipher = Fernet(key)
print(f"[PUB] Key: {key.decode()}")
print("=" * 55)
 
BROKER = "broker.hivemq.com"
PORT   = 1883
 
client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
client.connect(BROKER, PORT, 60)
client.loop_start()
 
 
def iso_now():
    return datetime.datetime.now().isoformat()
 
 
def encrypt_and_publish(topic: str, payload: dict):
    """Convert payload dict → JSON bytes → encrypt → publish to broker."""
    raw_json   = json.dumps(payload).encode()   # serialize to bytes
    ciphertext = cipher.encrypt(raw_json)       # encrypt with Fernet
    client.publish(topic, ciphertext)           # broker only sees ciphertext
    print(f"[PUB] Topic : {topic}")
    print(f"      Plain : {payload}")
    print(f"      Cipher: {ciphertext[:50]}...\n")
 
 
if __name__ == "__main__":
    print("\n--- Encrypted Truck Simulation ---\n")
    parcel_name = f"Parcel-{random.randint(100, 999)}"
 
    # Stage 1: announce parcel creation
    encrypt_and_publish("parcel/status", {
        "parcel_name": parcel_name,
        "status":      "pending",      # matches DB CHECK constraint
        "timestamp":   iso_now()
    })
    time.sleep(1)
 
    # Stage 2: simulate truck movement around Astana, Kazakhstan
    lat, lon = 51.1500, 71.4500
    for _ in range(5):
        lat += 0.002
        lon += 0.002
        encrypt_and_publish("truck/location", {
            "vehicle_id": 1,
            "lat":        lat,
            "lon":        lon,
            "timestamp":  iso_now()
        })
        encrypt_and_publish("parcel/status", {
            "parcel_name": parcel_name,
            "status":      "in_transit",   # [FIXED]
            "timestamp":   iso_now()
        })
        time.sleep(2)
 
    # Stage 3: mark as delivered
    encrypt_and_publish("parcel/status", {
        "parcel_name": parcel_name,
        "status":      "delivered",    # [FIXED]
        "timestamp":   iso_now()
    })
    print(f"[PUB] ✓ Parcel {parcel_name} delivered — all messages were encrypted!")
 
    client.loop_stop()
    client.disconnect()