import tkinter as tk
import qrcode
import json
import datetime
from io import BytesIO
from PIL import Image, ImageTk
import folium
import webbrowser
import sqlite3
import paho.mqtt.client as mqtt
import osmnx as ox
import networkx as nx

# ---------------- DATABASE ----------------
conn = sqlite3.connect("MQT.db", timeout=10)
cursor = conn.cursor()

# ---------------- MQTT ----------------
BROKER = "broker.hivemq.com"
TOPIC_LOC = "truck/location"
TOPIC_STAT = "parcel/status"

client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
print("Connecting to MQTT broker...")
client.connect(BROKER, 1883, 60)
client.loop_start()

# ---------------- OSMNX ROUTE ----------------
print("Loading the road network graph of Astana... (this may take 20–30 seconds)")
try:
    G = ox.graph_from_place("Astana, Kazakhstan", network_type='drive')
except Exception as e:
    print(f"Error of loading map: {e}")
    raise SystemExit(1)

# Baiterek → EXPO
start = (51.12825, 71.43047)
end   = (51.16280, 71.47050)
orig_node = ox.distance.nearest_nodes(G, start[1], start[0])
dest_node = ox.distance.nearest_nodes(G, end[1], end[0])
route_nodes = nx.shortest_path(G, orig_node, dest_node, weight='length')
route_coords = [(G.nodes[n]['y'], G.nodes[n]['x']) for n in route_nodes]

# ---------------- UI SETUP ----------------
root = tk.Tk()
root.title("Truck Route Dashboard")
root.geometry("1000x650")
root.configure(bg="#111")

left = tk.Frame(root, bg="#222", width=250)
left.pack(side="left", fill="y")
center = tk.Frame(root, bg="#111")
center.pack(side="left", expand=True, fill="both")
right = tk.Frame(root, bg="#222", width=250)
right.pack(side="right", fill="y")

title = tk.Label(center, text="TRUCK LIVE TRACKING", font=("Arial", 18, "bold"), fg="white", bg="#111")
title.pack(pady=20)

coord_label = tk.Label(center, text="", font=("Arial", 14), fg="white", bg="#111")
coord_label.pack(pady=10)
status_label = tk.Label(center, text="", font=("Arial", 14), fg="lime", bg="#111")
status_label.pack(pady=10)
parcel_label = tk.Label(center, text="", font=("Arial", 14), fg="cyan", bg="#111")
parcel_label.pack(pady=10)

qr_label = tk.Label(left, bg="#222")
qr_label.pack(pady=20)

history_box = tk.Text(right, height=20, width=30, bg="black", fg="lime")
history_box.pack(pady=20)

# ---------------- STATE ----------------
route_index = 0
parcel_counter = 1
map_opened = False

# ---------------- HELPERS ----------------
def generate_qr(parcel_id):
    qr = qrcode.make(f"Parcel-{parcel_id}")
    bio = BytesIO()
    qr.save(bio, format="PNG")
    bio.seek(0)
    img = Image.open(bio).resize((180, 180))
    return ImageTk.PhotoImage(img)

def save_to_db(parcel_name, lat, lon, status, is_new=False):
    now = datetime.datetime.now().isoformat()
    # saving track of car
    cursor.execute("""
        INSERT INTO "Traction logs" (vehicle_id, latitude, longitude, speed, timestamp) 
        VALUES (1, ?, ?, 40.0, ?)
    """, (lat, lon, now))
    
    # saving or updating parcel
    if is_new:
        cursor.execute("""
            INSERT INTO Parcels (parcel_name, sender, receiver, vehicle_id, destination, status, created_at) 
            VALUES (?, 'Warehouse', 'Client', 1, 'EXPO', ?, ?)
        """, (parcel_name, status, now))
    else:
        del_time = now if status == "Delivered" else None
        cursor.execute("UPDATE Parcels SET status=?, delivered_at=? WHERE parcel_name=?", 
                       (status, del_time, parcel_name))
    conn.commit()

def load_history():
    history_box.delete("1.0", tk.END)
    cursor.execute("SELECT parcel_name, status FROM Parcels ORDER BY parcel_id DESC LIMIT 10")
    for row in cursor.fetchall():
        history_box.insert(tk.END, f"{row[0]} → {row[1]}\n")

def update_map(lat, lon):
    m = folium.Map(location=[lat, lon], zoom_start=15)
    folium.PolyLine(route_coords, color="blue", weight=5, opacity=0.8).add_to(m)
    folium.Marker(route_coords[0], popup="Baiterek", icon=folium.Icon(color='green')).add_to(m)
    folium.Marker(route_coords[-1], popup="EXPO", icon=folium.Icon(color='red')).add_to(m)
    folium.Marker([lat, lon], popup="Truck", icon=folium.Icon(color='orange')).add_to(m)
    refresh = "<script>setTimeout(function(){ location.reload(); }, 2000);</script>"
    m.get_root().html.add_child(folium.Element(refresh))
    m.save("astana_route.html")

def open_map():
    global map_opened
    if not map_opened:
        webbrowser.open("astana_route.html")
        map_opened = True

tk.Button(left, text="Open Live Map", command=open_map, bg="orange").pack(pady=10)

# ---------------- UPDATE LOOP ----------------
def update():
    global route_index, parcel_counter, map_opened
    is_new_parcel = (route_index == 0)
    
    if route_index >= len(route_coords):
        route_index = 0
        parcel_counter += 1
        map_opened = False # map restart for new parcel
        return root.after(1000, update)

    lat, lon = route_coords[route_index]
    parcel_name = f"Parcel-{parcel_counter}"
    status = "Delivered" if route_index == len(route_coords)-1 else "In Transit"

    qr_img = generate_qr(parcel_counter)
    qr_label.config(image=qr_img)
    qr_label.image = qr_img

    coord_label.config(text=f"Lat: {lat:.6f}\nLon: {lon:.6f}")
    parcel_label.config(text=f"Parcel: {parcel_name}")
    status_label.config(text=f"Status: {status}")

    # publication MQTT (JSON)
    loc_payload = json.dumps({"vehicle_id": 1, "lat": lat, "lon": lon})
    stat_payload = json.dumps({"parcel_name": parcel_name, "status": status})
    client.publish(TOPIC_LOC, loc_payload)
    client.publish(TOPIC_STAT, stat_payload)

    # work with database
    save_to_db(parcel_name, lat, lon, status, is_new_parcel)
    load_history()
    update_map(lat, lon)

    route_index += 1
    root.after(400, update)

# clean when window closed
def on_closing():
    client.loop_stop()
    client.disconnect()
    conn.close()
    root.destroy()

root.protocol("WM_DELETE_WINDOW", on_closing)

# ---------------- START ----------------
if __name__ == "__main__":
    update()
    root.mainloop()