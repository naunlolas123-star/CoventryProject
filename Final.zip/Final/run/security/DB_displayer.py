import sqlite3
import hashlib
import getpass
import os

# Build absolute path to the shared database one level up, inside /db/
database = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "db", "Logistic.db")


def hash_password(password):
    """Hash a plain-text password with SHA-256 and return hex digest."""
    return hashlib.sha256(password.encode()).hexdigest()


def init_users():
    """Create the users table if it does not exist yet."""
    conn = sqlite3.connect(database)
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        user_id       INTEGER PRIMARY KEY AUTOINCREMENT,
        username      TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL
    )
    """)

    conn.commit()
    conn.close()


def register():
    """Ask for a new username/password and save them (password stored as hash)."""
    conn = sqlite3.connect(database)
    cursor = conn.cursor()

    username = input("Create username: ")
    password = getpass.getpass("Create password: ")   # characters are hidden while typing

    password_hash = hash_password(password)

    try:
        cursor.execute(
            "INSERT INTO users (username, password_hash) VALUES (?, ?)",
            (username, password_hash)
        )
        conn.commit()
        print("User created successfully!\n")
    except sqlite3.IntegrityError:
        # Triggered when the username already exists (UNIQUE constraint)
        print("Username already exists!\n")

    conn.close()


def login():
    """Check username + hashed password against the database. Returns True on success."""
    conn = sqlite3.connect(database)
    cursor = conn.cursor()

    username = input("Username: ")
    password = getpass.getpass("Password: ")

    password_hash = hash_password(password)

    cursor.execute(
        "SELECT * FROM users WHERE username=? AND password_hash=?",
        (username, password_hash)
    )

    user = cursor.fetchone()
    conn.close()

    if user:
        print("\nLogin successful!\n")
        return True
    else:
        print("\nInvalid username or password!\n")
        return False


def show_data():
    """Let the logged-in user pick a table and view all its rows."""
    conn = sqlite3.connect(database)
    cursor = conn.cursor()

    while True:
        print("\n1. Show Vehicles")
        print("2. Show Parcels")
        print("3. Show Logs")
        print("0. Back")

        choice = input("Choose: ").strip()

        if choice == "1":
            table = "vehicle"
        elif choice == "2":
            table = "parcels"
        elif choice == "3":
            table = "traction_logs"
        elif choice == "0":
            conn.close()
            return
        else:
            print("Invalid choice")
            continue

        # Read column names so we can print a header row
        cursor.execute(f"PRAGMA table_info({table})")
        columns = [row[1] for row in cursor.fetchall()]

        cursor.execute(f"SELECT * FROM {table}")
        rows = cursor.fetchall()

        print()

        if not rows:
            print(f"  Table '{table}' is empty — no data to show yet")
        else:
            header = " | ".join(f"{col:<15}" for col in columns)
            print(header)
            print("-" * len(header))

            for row in rows:
                print(" | ".join(f"{str(val):<15}" for val in row))

        print()
        break   # return to the data sub-menu after showing one table

    conn.close()


def main():
    """Entry point: register or log in, then browse data."""
    init_users()   # ensure the users table exists before anything else

    while True:
        print("1. Register")
        print("2. Login")
        print("0. Quit")

        choice = input("Choose: ").strip()

        if choice == "1":
            register()
        elif choice == "2":
            if login():
                while True:
                    print("\n1. View Data")
                    print("0. Logout")

                    option = input("Choose: ").strip()

                    if option == "1":
                        show_data()
                    elif option == "0":
                        print("\nLogged out.\n")
                        break
                    else:
                        print("Invalid option")
        elif choice == "0":
            print("Goodbye!")
            break
        else:
            print("Invalid choice\n")


main()
